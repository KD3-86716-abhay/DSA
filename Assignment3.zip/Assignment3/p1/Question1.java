package com.sunbeam;
//1. Create an array of integers. Reverse the array using stack
public class Question1 {
	private int arr[];
	private int top;
	private final int SIZE;
	
	public Question1(int size)
	{
		SIZE=size;
		arr=new int[SIZE];
		top=-1;
	}
	
	public void push(int value)
	{
		//elements are pushed on stack
		top++;
		arr[top]=value;
	}
	
//	public void display()
//	{
//		for(int i=top;i>-1;i--)
//		{
//			System.out.println(arr[top]);
//			pop();
//		}
//	}
	
	public int pop()
	{
		int temp = arr[top];
		//1. reposition top (dec)
		top--;
		return temp;
	}
	
	public boolean isEmpty() {
		return top == -1;
	}
	
	public boolean isFull() {
		return top == SIZE-1;
	}
}
