package com.sunbeam;

import java.util.Scanner;

public class Question1Main {

	public static void main(String[] args) {
		Question1 q1=new Question1(6);
//		Scanner sc=new Scanner(System.in);
		int arr[]= {10,20,30,40,50};
		
		for(int i=0;i<arr.length;i++)
			q1.push(arr[i]);
		
		for(int i=0;i<arr.length;i++)
			System.out.println(" "+q1.pop());
		
		
		
//		
//		q1.push(10);
//		q1.push(20);
//		q1.push(30);
//		q1.push(40);
//		
//		q1.display();
			
		
		

	}

}
