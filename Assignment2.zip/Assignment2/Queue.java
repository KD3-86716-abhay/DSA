package com.sandip.Queue;



public class Queue {
	
	int arr[];
	int front,rear;
	public static int SIZE;
	
	
	public Queue() {
		
	}
	
	public Queue(int size) {
		SIZE=size;
		arr=new int[size];
		front=rear=0;
	}
	
	public void push(int value) {
		rear++;
		arr[rear]=value;
		
		
	}
	public int pop() {
		front++;
	 int a =arr[front];
	
	return a;
	}
	
	public int peek() {
		return front;
	}
	
	public boolean isFull() {
		
		return rear==arr.length-1&&front==arr.length-1;
		
	}
	
	
	public boolean isEmpty()
	{
		
	return rear==0&&front==0;	
	}

	
	
	
	
	
	
	
	
	
	
	
	
}
