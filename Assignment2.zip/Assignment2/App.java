package com.sandip.Employee;



public class App {
	
	
	public static void sort(Employee arr[],int N) {
		
		for(int i=1; i<N;i++ ) {
			
			Employee temp=arr[i];
			int j;
			for( j=i-1;j>=0&&arr[j].salary>temp.salary;j--)
			{
			arr[j+1]=arr[j];
			
				
				
			}			
			try {
			
			arr[j+1]=temp;
			}catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		
		
	}

	public static void main(String[] args) {
		
		Employee arr[] ={new Employee("sandip",150),new Employee("prathmesh",200),new Employee("Abhay",100),new Employee("ritik",300)};
		
		sort(arr,arr.length);
		
		for (Employee employee : arr) {
			System.out.println(employee);
		}
		//System.out.println(Arrays(arr));
		
	}
	
}
