package com.sandip;

public class BST {
	

	static class Node{
		
		int data;
		Node left,right;
		public Node(int value) {

			data=value;
		left=right=null;
		}
		
	
		
	
		
		
		
		
	}

	Node root;
	
	public BST() {
		root=null;
	}
	
	private void addNode(int value,Node trav) {
		
		if(value<trav.data) {
			if(trav.left==null) {
				trav.left=new Node(value);
			}else {
				addNode(value,trav.left);
			}}else {
				if(trav.right==null) {
					trav.right=new Node(value);
					return;
					
				}else {
					addNode(value,trav.right);
				}
			}
			
			
			
			
			
		}
		
		
		
	private Node BinarySearch(int value,Node temp) {
		if(temp==null)
			return null;
		if(value==temp.data)
			return temp;
		else if (value<temp.data) {
			return BinarySearch(value, temp.left);
		}else {
			return BinarySearch(value, temp.right);		}
			
	}
	
	public Node BinarySearch(int value) {
		return BinarySearch(value,root);
	}
	
	
	public void addNode(int value) {
		Node newnode=new Node(value);
		if(root==null) {
			root=newnode;
		}else {
			

			addNode(value,root);
			
		}
		
		
		
		
		
		
		
	}
	
	
	

}
