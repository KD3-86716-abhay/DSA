package com.sandip;

import com.sandip.BST.Node;

public class App {

	public static void main(String[] args) {
		BST  s=new BST();
		s.addNode(10);
		s.addNode(20);
	Node  n=	s.BinarySearch(10);
		
	System.out.println(n.data);	
		
	}
	
	
}
