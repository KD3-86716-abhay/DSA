package com.sunbeam.p2;

 public class Stack {
//	private int top;
	
	private static class Node{
		private int data;
		private int head;
		private Node next;
//		private int top;
		public Node(int value) {
			this.data=value;
			this.next=null;
			}
	}
	private Node top;
	public Stack()
	{
		this.top=null;
	}

	public boolean isEmpty()
	{
		return top==null;
	}
	
	
	public void push(int value)
	{
		//create node
		Node nn=new Node(value);
		//if stack is empty
		nn.next=top;
		top=nn;		
	}
	
	public int pop()
	{
		if(top==null)
		{
			System.out.println("stack is empty");
			return 0;
		}
		else {
			int value=top.data;
			top=top.next;
			return value;
		}
		
	}
	
	public int peek()
	{
		if(isEmpty())
		{
			System.out.println("stack is empty");
		}
		return top.data;
	}
	
	public void display()
	{
		
		    Node current = top;
		    System.out.print("Stack: ");
		    while (current != null) {
		        System.out.print(current.data + " ");
		        current = current.next;
		    }
		    System.out.println();
		
	}
			
}
	
	
	
	
	

