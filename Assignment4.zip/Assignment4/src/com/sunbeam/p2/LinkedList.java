package com.sunbeam.p2;

import java.util.Scanner;

public class LinkedList {
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		
		
		int choice;
		do
		{
		System.out.println("1. stack operation\n 2. queue op");
		System.out.println("enter your choice");
		choice=sc.nextInt();
		
		switch(choice)
		{
		case 0:
			break;
		
		case 1:
		
			Stack s=new Stack();
			s.push(10);
			s.push(20);
			s.push(30);
			s.push(40);
		
			s.pop();
			s.pop();
//			s.pop();
			s.peek();
			s.display();
			break;
			
		case 2:
			Queue q1 = new Queue();
			
			q1.addFirst(40);
			q1.addFirst(30);
			q1.addFirst(20);
			q1.addFirst(10);
			q1.display();
			break;
			
		default:
			System.out.println("invalid choice");
			
		
		}
		
		}while(choice!=0);
		
		
		

	}

}
