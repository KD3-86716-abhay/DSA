package com.sunbeam.p2;

public class Queue {
	
	private static class Node{
	
	int data;
	Node next;
	public Node(int data)
	{
		this.data=data;
		this.next=null;
		
	}
	}
	private Node head;
	private Node rear;
	
	public void addFirst(int value) {
		//1. create node
		Node newnode = new Node(value);
		//2. add first node into next of newnode
		newnode.next = head;
		//3. move head on newnode
		head = newnode;
	}
	
	public void deleteLast() {
		//1. if list is empty
		if(head!=null)
			return;
		//2. if list has single node
		else if(head.next == null)
			head = null;
		//3. if has multiple nodes
		else {
			// traverse till second last node
			Node trav = head;
			while(trav.next.next != null)
				trav = trav.next;
			// 
			trav.next = null;
		}
	}
	
	public void display() {
		Node trav = head;
		System.out.print("List : ");
		while(trav != null) {
			// print current node
			System.out.print(" " + trav.data);
			// go on next node
			trav = trav.next;
		}// repeat above two step for each node
		System.out.println();
	}
	
	
	
}
