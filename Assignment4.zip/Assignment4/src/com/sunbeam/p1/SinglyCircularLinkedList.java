package com.sunbeam.p1;

public class SinglyCircularLinkedList {
		static class Node{
			private int data;
			private Node next;
			public Node(int value) {
				data = value;
				next =  null;
			}
		}
		
		private static Node tail;
		private static int size;
		public SinglyCircularLinkedList() {
			tail = null;
			size = 0;
		}
		
		public boolean isEmpty() {
			return tail == null;
		}
		
		public int size() {
			return size;
		}
		
		public void addFirst(int value) {
			Node nn = new Node(value);
			if(tail == null) {
				tail = nn;
				tail.next = nn;
			}
			
			else {
				nn.next = tail.next;
				tail.next = nn;
			}
			size++;
			System.out.println("size:="+size);
		}
		
		private static void addLast(int value) {
			Node nn = new Node(value);
			if(tail==null)
			{
				tail=nn;
				tail.next=tail;
			}
			else {
				nn.next=tail.next;
				tail.next=nn;
				tail=nn;
			}
			size++;
		}
		
		public void deleteFirst(int value) {
			Node nn=new Node(value);
			//1. if list is empty
			if(tail == null)
			{
				tail=nn;
				tail.next=nn;
			}
			//2. if list has single node
			
			else {
				tail.next=tail.next.next;
			}
			size--;
			System.out.println("size:="+size);
		}
		
		
		
		public void AddPosition(int value,int pos)
		{
			Node nn= new Node(value);
			
			if(size==0) {
				tail=nn;
				tail.next=tail;
			}
			else if(pos==1)
			{
				addFirst(value);
				return;
			}
			else if(pos==size+1)
			{
				addLast(value);
				return;
			}
			else {
				Node trav=tail.next;
				for(int i=1;i<pos-1;i++)
					trav=trav.next;
				nn.next=trav.next;
				trav.next=nn;	
			}
			size++;
		}
		
		public void display() {
			
			
			Node temp = tail.next;
			System.out.print("List : ");
			do {
				
				
				// print current node
				System.out.print(" " + temp.data);
				// go on next node
				temp = temp.next;
			}while(temp != tail);
			// repeat above two step for each node
			System.out.println(" "+tail.data);
			System.out.println();
		}
		
	
		
		
	}










	
