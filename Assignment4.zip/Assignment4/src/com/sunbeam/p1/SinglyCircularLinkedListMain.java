package com.sunbeam.p1;

public class SinglyCircularLinkedListMain {

	public static void main(String[] args) {
		
		SinglyCircularLinkedList l1 = new SinglyCircularLinkedList();
		
		l1.addFirst(40);
		l1.addFirst(30);
		l1.addFirst(20);
		l1.addFirst(10);
		//10 20 30 40
		
		//l1.addLast(50);
		//l1.addLast(60);
		
		
		//l1.deleteFirst();
		//l1.deleteLast();
		
		//l1.addPosition(100, 6);
		
		//l1.deletePosition(3);
		
		l1.AddPosition(50,3);
		l1.display();
		
	}

	

}
